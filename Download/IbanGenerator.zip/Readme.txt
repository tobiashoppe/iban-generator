IBAN Generator

1. Installation
	- Die ZIP-Datei herunterladen und entpacken

2. Starten des IBAN Generators
	- In den Ordner "IBAN-Generator" wechseln
	- Doppelklick auf "IBAN-Generator.exe"